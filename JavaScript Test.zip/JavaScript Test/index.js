console.log('############################\nWelcome to the joke factory!\nLet me tell you something about programming:');

function getRandomJoke() {
    return Math.floor(Math.random() * programmingJokes.length);
  }
function getRandomSvar() {
    return Math.floor(Math.random() * programmingSvar.length);
  }

  const id = [
    "1",
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
    "10"
  ]

  const programmingJokes = [
    "Why don't programmers like nature?",
    "Why did the CSS developer go to therapy?",
    "How do you comfort a JavaScript developer?",
    "Why did the CSS developer leave the restaurant?",
    "Why did the JavaScript developer go missing?",
    "Why did the HTML tag go to the party?",
    "Why do JavaScript developers wear glasses?",
    "Why don't programmers like to use inline styles?",
    "Why did the CSS selector break up with the HTML element?",
    "Why did the CSS developer apply for a job?"
  ];

  const programmingSvar = [
    "It has too many bugs.",
    "To get rid of his margins.",
    "You console them.",
    "Because it had no class.",
    "Because he didn't know when to return.",
    "Because it wanted to break the line.",
    "Because they don't C#.",
    "Because they want to be classy.",
    "It found someone more specific.",
    "They wanted to get a position."
  ];

console.log('   ');
  
const jokeIndex = getRandomJoke();
let idJoke = jokeIndex;
console.log('Joke #' + (jokeIndex + 1));
console.log('Question:', programmingJokes[jokeIndex]);

let jokeSvar = jokeIndex;
console.log('Answer:', programmingSvar[jokeSvar]);

console.log('  ');

let jokeIndex2;
do {
    jokeIndex2 = getRandomJoke();
} while (jokeIndex2 === jokeIndex);

let idJoke2 = jokeIndex2;
console.log('Joke #' + (jokeIndex2 + 1))
console.log('Question:', programmingJokes[jokeIndex2]);

let jokeSvar2 = jokeIndex2;
console.log('Answer:', programmingSvar[jokeSvar2]);


